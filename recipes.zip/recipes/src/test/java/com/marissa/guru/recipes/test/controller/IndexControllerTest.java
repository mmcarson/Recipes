package com.marissa.guru.recipes.test.controller;

import java.util.HashSet;

import org.junit.*;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Mockito;
import org.springframework.ui.Model;

import com.marissa.guru.recipes.controller.IndexController;
import com.marissa.guru.recipes.model.Category;
import com.marissa.guru.recipes.model.Recipe;
import com.marissa.guru.recipes.service.CategoryService;
import com.marissa.guru.recipes.service.RecipeService;

public class IndexControllerTest {
	
	IndexController iController;
	
	@Mock
	RecipeService recService;
	
	@Mock
	CategoryService catService;
	
	@Mock
	Model model;
	
	@Before
	public void setUp() throws Exception{
		MockitoAnnotations.initMocks(this);
		iController = new IndexController(catService, recService);
	}
	
	@Test
	public void getIndexPage() throws Exception{
		Recipe recipe = new Recipe();
		recipe.setDescription("Sample Recipe");
		Category category = new Category();
		category.setDescription("Sample Category");
		
        HashSet<Recipe> recipesData = new HashSet<Recipe>();
        recipesData.add(recipe);
        category.setRecipes(recipesData);
        HashSet<Category> categoriesData = new HashSet<Category>();
        categoriesData.add(category);
        recipe.setCategories(categoriesData);
        
        Mockito.when(recService.getRecipes()).thenReturn(recipesData);
        Mockito.when(catService.getCategories()).thenReturn(categoriesData);
        
        //System.out.println(iController.getIndexPage(model));
        Assert.assertEquals(iController.getIndexPage(model), "index");
        Mockito.verify(recService, Mockito.times(1)).getRecipes();
        Mockito.verify(catService, Mockito.times(1)).getCategories();
        Mockito.verify(model, Mockito.times(1)).addAttribute(Mockito.eq("recipes"), Mockito.eq(recipesData));
        Mockito.verify(model, Mockito.times(1)).addAttribute(Mockito.eq("categories"), Mockito.eq(categoriesData));
	}
}

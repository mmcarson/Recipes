package com.marissa.guru.recipes.test.converter;

import static org.junit.Assert.*;

import java.math.BigDecimal;

import org.junit.BeforeClass;
import org.junit.Test;

import com.marissa.guru.recipes.command.*;
import com.marissa.guru.recipes.converter.*;
import com.marissa.guru.recipes.model.*;

public class ConverterTest {
	static Category category;
	static Direction direction;
	static Ingredient ingredient;
	static UnitOfMeasure uom;
	static Notes notes;
	static Recipe recipe;
	@BeforeClass
	public static void setUp() throws Exception{
		category = new Category();
		category.setDescription("Sample description");
		category.setId(1L);
		direction = new Direction();
		direction.setDescription("Sample description");
		direction.setId(1L);
		direction.setStepNumber(1L);
		ingredient = new Ingredient();
		ingredient.setAmount(new BigDecimal(1));
		ingredient.setDescription("Sample Description");
		ingredient.setId(1L);
		uom = new UnitOfMeasure();
		uom.setDescription("sample description");
		uom.setId(1L);
		ingredient.setUom(uom);
		notes = new Notes();
		notes.setId(1L);
		notes.setRecipeNotes("Sample notes");
		recipe = new Recipe();
		recipe.getCategories().add(category);
		recipe.setCookTime(1);
		recipe.setDescription("sample");
		recipe.setDifficulty(Difficulty.EASY);
		recipe.getDirections().add(direction);
		recipe.setId(1L);
		recipe.getIngredients().add(ingredient);
		recipe.setNotes(notes);
		recipe.setPrepTime(1);
		recipe.setServings(1);
		recipe.setSource("samp");
		recipe.setUrl("sampl");
	}
	@Test
	public void categoryTest() throws Exception{
		CategoryCommand catCommand = new CategoryToCategoryCommand().convert(category);
		assertEquals(category, new CategoryCommandToCategory().convert(catCommand));
	}
	@Test
	public void directionTest() throws Exception{
		DirectionCommand dirCommand = new DirectionToDirectionCommand().convert(direction);
		assertEquals(direction, new DirectionCommandToDirection().convert(dirCommand));
	}
	@Test
	public void uomTest() throws Exception{
		UnitOfMeasureCommand uomCommand = new UnitOfMeasureToUnitOfMeasureCommand().convert(uom);
		assertEquals(uom, new UnitOfMeasureCommandToUnitOfMeasure().convert(uomCommand));
	}
	@Test
	public void ingredientTest() throws Exception{
		IngredientCommand ingCommand = new IngredientToIngredientCommand(
				new UnitOfMeasureToUnitOfMeasureCommand()).convert(ingredient);
		assertEquals(ingredient, new IngredientCommandToIngredient(
				new UnitOfMeasureCommandToUnitOfMeasure()).convert(ingCommand));
	}
	@Test
	public void notesTest() throws Exception{
		NotesCommand notesCommand = new NotesToNotesCommand().convert(notes);
		assertEquals(notes, new NotesCommandToNotes().convert(notesCommand));
	}
	@Test
	public void recipeTest() throws Exception{
		RecipeCommand recCommand = new RecipeToRecipeCommand(new CategoryToCategoryCommand(),
				new DirectionToDirectionCommand(), new IngredientToIngredientCommand(
						new UnitOfMeasureToUnitOfMeasureCommand()),
				new NotesToNotesCommand()).convert(recipe);
		assertEquals(recipe, new RecipeCommandToRecipe(new CategoryCommandToCategory(),
				new DirectionCommandToDirection(), new IngredientCommandToIngredient(
						new UnitOfMeasureCommandToUnitOfMeasure()),
				new NotesCommandToNotes()).convert(recCommand));
	}
}

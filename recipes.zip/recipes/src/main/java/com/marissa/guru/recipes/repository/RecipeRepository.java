package com.marissa.guru.recipes.repository;

import org.springframework.data.repository.CrudRepository;

import com.marissa.guru.recipes.model.Recipe;

public interface RecipeRepository extends CrudRepository<Recipe, Long>{

}

package com.marissa.guru.recipes.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.marissa.guru.recipes.command.CategoryCommand;
import com.marissa.guru.recipes.model.Category;

@Component
public class CategoryToCategoryCommand implements Converter<Category, CategoryCommand> {

	@Override
	public CategoryCommand convert(Category source) {
		if (source == null){
			return null;
		}
		final CategoryCommand catc = new CategoryCommand();
		catc.setDescription(source.getDescription());
		catc.setId(source.getId());
		return catc;
	}

}

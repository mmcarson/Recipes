package com.marissa.guru.recipes.service;

import java.util.Set;

import com.marissa.guru.recipes.command.RecipeCommand;
import com.marissa.guru.recipes.model.Recipe;

public interface RecipeService {
	public Iterable<Recipe> getRecipes();
	public Recipe findById(Long id);
	public void deleteById(Long id);
	public RecipeCommand saveRecipe(RecipeCommand command);
	public RecipeCommand findCommandById(Long id);
}

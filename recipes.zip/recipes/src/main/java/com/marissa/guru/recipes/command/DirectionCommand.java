package com.marissa.guru.recipes.command;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@NoArgsConstructor
public class DirectionCommand implements Comparable {
	private Long id;
	private Long stepNumber;
	private String description;
	@Override
	public int compareTo(Object o) {
		return stepNumber.compareTo(((DirectionCommand)o).stepNumber);
	}
}

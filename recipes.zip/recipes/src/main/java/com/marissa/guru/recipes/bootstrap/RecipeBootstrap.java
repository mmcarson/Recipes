package com.marissa.guru.recipes.bootstrap;

import java.math.BigDecimal;

import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import com.marissa.guru.recipes.model.Difficulty;
import com.marissa.guru.recipes.model.*;
import com.marissa.guru.recipes.repository.*;

@Component
public class RecipeBootstrap implements ApplicationListener<ContextRefreshedEvent> {

	private CategoryRepository catRepo;
	private RecipeRepository recRepo;
	private UnitOfMeasureRepository uomRepo;
	
	public RecipeBootstrap(CategoryRepository catRepo, RecipeRepository recRepo, UnitOfMeasureRepository uomRepo) {
		this.catRepo = catRepo;
		this.recRepo = recRepo;
		this.uomRepo = uomRepo;
	}

	@Override
	public void onApplicationEvent(ContextRefreshedEvent arg0) {
		initData();
		System.out.println("initData() has been called");
	}

	@SuppressWarnings("unused")
	private void initData() {
		// TODO Auto-generated method stub
		Recipe guacamole = new Recipe();
		Notes guacNotes = new Notes(guacamole, "Be careful handling chiles if using. "
				+ "Wash your hands thoroughly after handling and do not touch your eyes "
				+ "or the area near your eyes with your hands for several hours.");
		guacamole.setDescription("How to Make Perfect Guacamole");
		guacamole.setCookTime(0);
		guacamole.setPrepTime(10);
		guacamole.setDifficulty(Difficulty.EASY);
		guacamole.setServings(new Integer(3));
		guacamole.setSource("Elise Bauer");
		guacamole.setUrl("https://www.simplyrecipes.com/recipes/perfect_guacamole/");
		Direction g1 = new Direction(1L, "Cut avocado, remove flesh: Cut the avocados "
				+ "in half. Remove seed. Score the inside of the avocado with a blunt "
				+ "knife and scoop out the flesh with a spoon. (See How to Cut and Peel an Avocado.) "
				+ "Place in a bowl.", guacamole);
		Direction g2 = new Direction(2L, "Mash with a fork: Using a fork, roughly mash the avocado. "
				+ "(Don't overdo it! The guacamole should be a little chunky.)", guacamole);
		Direction g3 = new Direction(3L, "Add salt, lime juice, and the rest: Sprinkle "
				+ "with salt and lime (or lemon) juice. The acid in the lime juice will "
				+ "provide some balance to the richness of the avocado and will help delay "
				+ "the avocados from turning brown. Add the chopped onion, cilantro, "
				+ "black pepper, and chiles. Chili peppers vary individually in their hotness. "
				+ "So, start with a half of one chili pepper and add to the guacamole to your "
				+ "desired degree of hotness. Remember that much of this is done to taste because "
				+ "of the variability in the fresh ingredients. Start with this recipe and adjust "
				+ "to your taste.", guacamole);
		Direction g4 = new Direction(4L, "Cover with plastic and chill to store: Place plastic wrap "
				+ "on the surface of the guacamole cover it and to prevent air reaching it. "
				+ "(The oxygen in the air causes oxidation which will turn the guacamole brown.) "
				+ "Refrigerate until ready to serve. Chilling tomatoes hurts their flavor, so if "
				+ "you want to add chopped tomato to your guacamole, add it just before serving.", guacamole);
		Ingredient avocado = new Ingredient("ripe avocados", new BigDecimal(2), guacamole);
		Ingredient kosherSalt = new Ingredient("Kosher salt", new BigDecimal(.5), 
				uomRepo.findByDescription("Teaspoon").get(), guacamole);
		Ingredient juice = new Ingredient("fresh lemon or lime juice", new BigDecimal(1),
				uomRepo.findByDescription("Tablespoon").get(), guacamole);
		Ingredient onion = new Ingredient("minced red onion or thinly sliced green onion", 
				new BigDecimal(2), uomRepo.findByDescription("Tablespoon").get(), guacamole);
		Ingredient chiles = new Ingredient("serrano chiles, stems and seeds removed, minced",
				new BigDecimal(2), guacamole);
		Ingredient cilantro = new Ingredient("cilantro (leaves and tender stems), finely chopped",
				new BigDecimal(2), uomRepo.findByDescription("Tablespoon").get(), guacamole);
		Ingredient pepper = new Ingredient("fresh ground black pepper", new BigDecimal(1),
				uomRepo.findByDescription("Dash").get(), guacamole);
		Ingredient tomato = new Ingredient("ripe tomato, seeds and pulp removed, chopped", 
				new BigDecimal(.5), guacamole);
		Category mexican = catRepo.findByDescription("Mexican").get();
		guacamole.getCategories().add(mexican);
		guacamole.getCategories().add(catRepo.findByDescription("American").get());
		recRepo.save(guacamole);
		
		Recipe chickenNoodle = new Recipe();
		chickenNoodle.setDescription("Homemade Chicken Noodle Soup");
		Notes chickenNoodleNotes = new Notes(chickenNoodle, "Prep the vegetables for the stock up front, "
				+ "then prep the vegetables for the soup while the stock is simmering "
				+ "to save overall start-to-finish time." + '\n'
				+ "While this recipe shows the step for entirely homemade chicken soup, "
				+ "you could also easily make this chicken noodle soup starting with already "
				+ "prepared stock and some raw chicken. "
				+ "Use about 2 quarts of chicken stock, and 2 boneless skinless chicken breasts "
				+ "and 2 chicken thighs and proceed to step 6. Making soup this way will "
				+ "take about 30 minutes.");
		chickenNoodle.setCookTime(120);
		chickenNoodle.setPrepTime(15);
		chickenNoodle.setDifficulty(Difficulty.MODERATE);
		chickenNoodle.setServings(12);
		chickenNoodle.setSource("Elise Bauer");
		chickenNoodle.setUrl("https://www.simplyrecipes.com/recipes/chicken_noodle_soup/");
		Direction c1 = new Direction(1L, "Separate breast and thigh meat from bones: "
				+ "Remove the breast meat from the breast bones, and the thigh meat "
				+ "from the thigh bone, place in a bowl, cover and chill in the refrigerator "
				+ "until needed towards the end of preparing the soup."
				+ "Remove and discard the largest pieces of breast and thigh skin. "
				+ "Cut away and discard excess fat from chicken pieces.", chickenNoodle);
		Direction c2 = new Direction (2L, "Parboil bones for 3 minutes: Place breast and "
				+ "thigh bones, the back, "
				+ "leg, neck, and wings in a large (8 quart) pot. Cover with water. "
				+ "Bring to a full rolling boil. Boil for 3 minutes. After 3 minutes, "
				+ "remove from heat, drain off the water, rinse the bones and the pot.", 
				chickenNoodle);
		Direction c3 = new Direction (3L, "Make stock with parboiled bones, celery, carrots, onion, garlic, "
				+ "thyme, parsley, peppercorns: Return the now parboiled bones to the clean pot. "
				+ "Add a couple carrots and a couple celery ribs, each cut into 2 inch chunks, "
				+ "and some celery tops if you have them, to the pot with the chicken. "
				+ "(Fennel tops or leek greens can be added too, if you have them.)"
				+ "Add the quartered onion, garlic cloves, thyme, one-half of the parsley, "
				+ "and the peppercorns to the pot. Cover with an inch or two of water "
				+ "(about 3 quarts).  Bring to a low simmer (about 185°F) and let simmer "
				+ "(the stock should be just barely bubbling), partially covered, for 1 1/2 hours.", chickenNoodle);
		Direction c4 = new Direction (4L, "Strain bones and solids from the stock: At the end of 1 1/2 hours strain "
				+ "out the bones and vegetables, reserving the stock. If you want, set aside and "
				+ "strip the bones of any remaining meat. After parboiling and 1 1/2 hours of "
				+ "cooking the meat will be rather dry and tasteless, though you could use it "
				+ "in a chicken salad.  Rinse out the pot and return the stock to the pot.", chickenNoodle);
		Direction c5 = new Direction (5L, "Salt the stock: Taste the stock. It should be rather bland because up to now,"
				+ " no salt has been added. Add salt to taste. As a guideline, for each quart of "
				+ "stock, add 2 teaspoons of salt.", chickenNoodle);
		Direction c6 = new Direction (6L, "Add carrots, celery: Add the sliced carrots and celery to the stock, "
				+ "bring to a simmer.", chickenNoodle);
		Direction c7 = new Direction (7L, "Cut raw chicken breast and thigh meat, add to stock: "
				+ "Cut the chicken breast and thigh meat into bite-sized pieces. "
				+ "Add to the pot with the carrots, celery, and stock. Return to a low simmer.", chickenNoodle);
		Direction c8 = new Direction(8L, "Add noodles, bring to simmer: Add the egg noodles and return to a simmer. "
				+ "Note that the noodles will expand substantially in the soup broth as they cook. Simmer "
				+ "until the egg noodles are just barely cooked through, al dente "
				+ "(about 5 minutes or so, depending on your package of noodles), "
				+ "and the chicken is just cooked through.", chickenNoodle);
		Direction c9 = new Direction (9L, "Add parsley, salt, pepper, thyme to serve: "
				+ "Stir in a handful of chopped fresh parsley. "
				+ "Add freshly ground black pepper, more thyme, and more salt to taste.", chickenNoodle);
		UnitOfMeasure pound = new UnitOfMeasure();
		pound.setDescription("lb");
		uomRepo.save(pound);
		Ingredient chicken = new Ingredient("chicken, cut into parts--breast, thighs, backs,"
				+ " wings, and neck (if available", new BigDecimal(3.5), pound, chickenNoodle);
		Ingredient carrots = new Ingredient("carrots (2 carrots scrubbed clean, but not peeled, "
				+ "cut into 2 inch chunks for the stock, 3 carrots peeled and cut into 1/4-inch "
				+ "rounds for the soup)", new BigDecimal(5), chickenNoodle);
		Ingredient celery = new Ingredient("ribs of celery (2 ribs cut into 2 inch pieces for the stock, "
				+ "3 ribs cut into 1/4-inch thick slices for the soup), "
				+ "including celery tops for the stock", new BigDecimal(5), chickenNoodle);
		Ingredient onion1 = new Ingredient("onion, quartered (for stock, peel on is okay)", 
				new BigDecimal(1), chickenNoodle);
		Ingredient garlic = new Ingredient("cloves of garlic, peel on, cut in half", 
				new BigDecimal(3), chickenNoodle);
		Ingredient thyme = new Ingredient("dried thyme", new BigDecimal(1), 
				uomRepo.findByDescription("Teaspoon").get(), chickenNoodle);
		Ingredient parsley = new Ingredient("bunch of parsley", new BigDecimal(1), chickenNoodle);
		Ingredient peppercorn = new Ingredient("whole peppercorns", new BigDecimal(5), chickenNoodle);
		Ingredient salt = new Ingredient("Salt", null, chickenNoodle);
		Ingredient noodle = new Ingredient("egg noodles", new BigDecimal(.5), pound, chickenNoodle);
		Ingredient blackPepper = new Ingredient("Freshly ground black pepper", null, chickenNoodle);
		chickenNoodle.getCategories().add(catRepo.findByDescription("American").get());
		recRepo.save(chickenNoodle);
	}

}

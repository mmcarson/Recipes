package com.marissa.guru.recipes.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.marissa.guru.recipes.command.IngredientCommand;
import com.marissa.guru.recipes.model.Ingredient;

@Component
public class IngredientToIngredientCommand implements Converter<Ingredient, IngredientCommand> {

	final private UnitOfMeasureToUnitOfMeasureCommand uomConverter;
	
	public IngredientToIngredientCommand(UnitOfMeasureToUnitOfMeasureCommand uomConverter) {
		this.uomConverter = uomConverter;
	}

	@Override
	public IngredientCommand convert(Ingredient source) {
		if (source == null)
			return null;
		final IngredientCommand ic = new IngredientCommand();
		ic.setAmount(source.getAmount());
		ic.setDescription(source.getDescription());
		ic.setId(source.getId());
		ic.setUom(uomConverter.convert(source.getUom()));
		return ic;
	}

}

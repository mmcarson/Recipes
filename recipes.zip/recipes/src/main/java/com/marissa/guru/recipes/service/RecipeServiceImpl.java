package com.marissa.guru.recipes.service;

import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.marissa.guru.recipes.command.RecipeCommand;
import com.marissa.guru.recipes.converter.RecipeCommandToRecipe;
import com.marissa.guru.recipes.converter.RecipeToRecipeCommand;
import com.marissa.guru.recipes.model.Recipe;
import com.marissa.guru.recipes.repository.RecipeRepository;

import antlr.collections.List;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class RecipeServiceImpl implements RecipeService {
	
	RecipeRepository recRepo; 
	RecipeToRecipeCommand recToRecC;
	RecipeCommandToRecipe recCToRec;
	
	public RecipeServiceImpl(RecipeRepository recRepo, RecipeToRecipeCommand recToRecC,
			RecipeCommandToRecipe recCToRec) {
		this.recRepo = recRepo;
		this.recToRecC = recToRecC;
		this.recCToRec = recCToRec;
	}

	@Override
	public Iterable<Recipe> getRecipes() {
		Iterable<Recipe> recipes = recRepo.findAll();
		return recipes;
	}

	@Override
	public Recipe findById(Long id) {
		return recRepo.findById(id).get();
	}

	@Transactional
	@Override
	public RecipeCommand saveRecipe(RecipeCommand command) {
		Recipe detachedRecipe = recCToRec.convert(command);
		Recipe savedRecipe = recRepo.save(detachedRecipe);
		log.debug("Saved RecipeID: " + savedRecipe.getId());
		return recToRecC.convert(savedRecipe);
	}

	@Override
	public void deleteById(Long l) {
		recRepo.deleteById(l);
	}

	@Override
	public RecipeCommand findCommandById(Long id) {
		return recToRecC.convert(findById(id));
	}
}

package com.marissa.guru.recipes.model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.Lob;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;

import antlr.collections.List;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.JoinColumn;

@Data
@Entity
@EqualsAndHashCode(exclude = {"categories"})
public class Recipe {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	private String description;
	private Integer prepTime;
	private Integer cookTime;
	private Integer servings;
	private String source; 
	private String url;
	
	@ManyToMany
	@JoinTable(name = "recipe_category", joinColumns = @JoinColumn(name = "recipe_id"), 
	inverseJoinColumns = @JoinColumn(name = "category_id"))
	private Set<Category> categories;
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "recipe")
	@OrderBy("stepNumber")
	private SortedSet<Direction> directions;
	
	@Enumerated(value = EnumType.STRING)
	private Difficulty difficulty;
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "recipe")
	private Set<Ingredient> ingredients;
	
	@Lob
	private Byte[] image;
	
	@OneToOne(cascade = CascadeType.ALL)
	private Notes notes;
	
	public Recipe() {
		this.categories = new HashSet<Category>();
		this.ingredients = new HashSet<Ingredient>();
		this.directions = new TreeSet<Direction>();
	}
	
}

package com.marissa.guru.recipes.command;

import java.math.BigDecimal;

import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import com.github.kiprobinson.bigfraction.BigFraction;
import com.marissa.guru.recipes.model.Recipe;
import com.marissa.guru.recipes.model.UnitOfMeasure;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class IngredientCommand {
	private Long id;
	private String description; 
	private BigDecimal amount;
	private UnitOfMeasureCommand uom;
	
	@Override
	public String toString() {
		String f;
		try { 
			f = BigFraction.valueOf(amount).toMixedString();
		} catch (Exception e) {
			//e.printStackTrace();
			f = "";
		}
		return f + ' ' + (uom == null ? "" : uom) + ' ' + description;
	}
}

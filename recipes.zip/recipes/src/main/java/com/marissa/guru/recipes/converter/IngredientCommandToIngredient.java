package com.marissa.guru.recipes.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.marissa.guru.recipes.command.IngredientCommand;
import com.marissa.guru.recipes.model.Ingredient;

@Component
public class IngredientCommandToIngredient implements Converter<IngredientCommand, Ingredient> {

	private final UnitOfMeasureCommandToUnitOfMeasure uomConverter;
	
	public IngredientCommandToIngredient(UnitOfMeasureCommandToUnitOfMeasure uomConverter) {
		this.uomConverter = uomConverter;
	}

	@Override
	public Ingredient convert(IngredientCommand source) {
		if (source == null)
			return null;
		final Ingredient i = new Ingredient();
		i.setAmount(source.getAmount());
		i.setDescription(source.getDescription());
		i.setId(source.getId());
		i.setUom(uomConverter.convert(source.getUom()));
		return i;
	}

}

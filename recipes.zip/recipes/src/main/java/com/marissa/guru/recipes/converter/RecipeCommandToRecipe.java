package com.marissa.guru.recipes.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.marissa.guru.recipes.command.CategoryCommand;
import com.marissa.guru.recipes.command.DirectionCommand;
import com.marissa.guru.recipes.command.IngredientCommand;
import com.marissa.guru.recipes.command.RecipeCommand;
import com.marissa.guru.recipes.model.Recipe;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class RecipeCommandToRecipe implements Converter<RecipeCommand, Recipe> {
	
	final private CategoryCommandToCategory catConverter;
	final private DirectionCommandToDirection dirConverter;
	final private IngredientCommandToIngredient ingConverter;
	final private NotesCommandToNotes notesConverter;

	public RecipeCommandToRecipe(CategoryCommandToCategory catConverter, DirectionCommandToDirection dirConverter,
			IngredientCommandToIngredient ingConverter, NotesCommandToNotes notesConverter) {
		this.catConverter = catConverter;
		this.dirConverter = dirConverter;
		this.ingConverter = ingConverter;
		this.notesConverter = notesConverter;
	}

	@Override
	public Recipe convert(RecipeCommand source) {
		if (source == null)
			return null;
		final Recipe recipe = new Recipe();
		for (CategoryCommand categoryC: source.getCategories()){
			log.debug("CategoryCommand found: " + categoryC);
			recipe.getCategories().add(catConverter.convert(categoryC));
		}
		for (DirectionCommand directionC: source.getDirections()){
			log.debug("DirectionCommand found: " + directionC);
			recipe.getDirections().add(dirConverter.convert(directionC));
		}
		for (IngredientCommand ingredientC: source.getIngredients()){
			log.debug("IngredientCommand found: " + ingredientC);
			recipe.getIngredients().add(ingConverter.convert(ingredientC));
		}
		recipe.setNotes(notesConverter.convert(source.getNotes()));
		recipe.setCookTime(source.getCookTime());
		recipe.setDescription(source.getDescription());
		recipe.setDifficulty(source.getDifficulty());
		recipe.setId(source.getId());
		recipe.setPrepTime(source.getPrepTime());
		recipe.setServings(source.getServings());
		recipe.setSource(source.getSource());
		recipe.setUrl(source.getUrl());
		return recipe;
	}

}

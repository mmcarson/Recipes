package com.marissa.guru.recipes.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.marissa.guru.recipes.command.UnitOfMeasureCommand;
import com.marissa.guru.recipes.model.UnitOfMeasure;

@Component
public class UnitOfMeasureToUnitOfMeasureCommand implements Converter<UnitOfMeasure, UnitOfMeasureCommand> {

	@Override
	public UnitOfMeasureCommand convert(UnitOfMeasure source) {
		if (source == null){
			return null;
		}
		final UnitOfMeasureCommand uomc = new UnitOfMeasureCommand();
		uomc.setDescription(source.getDescription());
		uomc.setId(source.getId());
		return uomc;
	}

}

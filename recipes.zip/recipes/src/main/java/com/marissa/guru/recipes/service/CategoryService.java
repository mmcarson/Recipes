package com.marissa.guru.recipes.service;

import java.util.Set;

import com.marissa.guru.recipes.command.CategoryCommand;
import com.marissa.guru.recipes.model.Category;

public interface CategoryService {
	public Iterable<Category> getCategories();
	public Category findById(Long l);
	public void deleteById(Long l);
	public CategoryCommand saveCategoryCommand(CategoryCommand command);
	public CategoryCommand findCommandById (Long id);
}

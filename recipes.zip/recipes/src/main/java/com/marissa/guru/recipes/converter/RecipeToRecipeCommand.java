package com.marissa.guru.recipes.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.marissa.guru.recipes.command.RecipeCommand;
import com.marissa.guru.recipes.model.Category;
import com.marissa.guru.recipes.model.Direction;
import com.marissa.guru.recipes.model.Ingredient;
import com.marissa.guru.recipes.model.Recipe;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class RecipeToRecipeCommand implements Converter<Recipe, RecipeCommand> {
	
	final private CategoryToCategoryCommand catConverter;
	final private DirectionToDirectionCommand dirConverter;
	private final IngredientToIngredientCommand ingConverter;
	private final NotesToNotesCommand notesConverter;

	public RecipeToRecipeCommand(CategoryToCategoryCommand catConverter, DirectionToDirectionCommand dirConverter,
			IngredientToIngredientCommand ingConverter, NotesToNotesCommand notesConverter) {
		this.catConverter = catConverter;
		this.dirConverter = dirConverter;
		this.ingConverter = ingConverter;
		this.notesConverter = notesConverter;
	}

	@Override
	public RecipeCommand convert(Recipe source) {
		if (source == null)
			return null;
		final RecipeCommand recc = new RecipeCommand();
		for (Category category: source.getCategories()){
			log.debug("Category found: " + category);
			recc.getCategories().add(catConverter.convert(category));
		}
		for (Direction direction: source.getDirections()){
			log.debug("Direction found: " + direction);
			recc.getDirections().add(dirConverter.convert(direction));
		}
		for (Ingredient ingredient: source.getIngredients()){
			log.debug("Ingredient found: " + ingredient);
			recc.getIngredients().add(ingConverter.convert(ingredient));
		}
		recc.setNotes(notesConverter.convert(source.getNotes()));
		recc.setCookTime(source.getCookTime());
		recc.setDescription(source.getDescription());
		recc.setDifficulty(source.getDifficulty());
		recc.setId(source.getId());
		recc.setPrepTime(source.getPrepTime());
		recc.setServings(source.getServings());
		recc.setSource(source.getSource());
		recc.setUrl(source.getUrl());
		return recc;
	}

}

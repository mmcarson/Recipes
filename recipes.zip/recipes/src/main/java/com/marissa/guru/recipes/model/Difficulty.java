package com.marissa.guru.recipes.model;

public enum Difficulty {
	EASY("Easy"), MODERATE("Moderate"), HARD("Hard");
	private String s;
	private Difficulty(String s){
		this.s = s;
	}
	@Override
	public String toString(){
		return s;
	}
}

package com.marissa.guru.recipes.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.marissa.guru.recipes.command.NotesCommand;
import com.marissa.guru.recipes.model.Notes;

@Component
public class NotesToNotesCommand implements Converter<Notes, NotesCommand> {

	@Override
	public NotesCommand convert(Notes source) {
		if (source == null)
			return null;
		final NotesCommand nc = new NotesCommand();
		nc.setId(source.getId());
		nc.setRecipeNotes(source.getRecipeNotes());
		return nc;
	}

}

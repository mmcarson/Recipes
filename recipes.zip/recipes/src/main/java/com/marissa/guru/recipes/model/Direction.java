package com.marissa.guru.recipes.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@EqualsAndHashCode(exclude = {"recipe"})
public class Direction implements Comparable{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private Long stepNumber;
	
	@Lob
	private String description;
	
	@ManyToOne
	Recipe recipe;

	public Direction(Long stepNumber, String description, Recipe recipe) {
		this.stepNumber = stepNumber;
		this.description = description;
		this.recipe = recipe;
		recipe.getDirections().add(this);
	}

	@Override
	public int compareTo(Object o) {
		Direction d = (Direction)o;
		
		return this.stepNumber.compareTo(d.stepNumber);
	}

	@Override
	public String toString() {
		return "Direction [id=" + id + ", stepNumber=" + stepNumber + ", description=" + description + "]";
	}
	
}

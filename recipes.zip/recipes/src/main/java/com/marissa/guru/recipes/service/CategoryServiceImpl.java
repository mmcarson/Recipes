package com.marissa.guru.recipes.service;

import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.marissa.guru.recipes.command.CategoryCommand;
import com.marissa.guru.recipes.converter.CategoryCommandToCategory;
import com.marissa.guru.recipes.converter.CategoryToCategoryCommand;
import com.marissa.guru.recipes.model.Category;
import com.marissa.guru.recipes.repository.CategoryRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CategoryServiceImpl implements CategoryService {
	CategoryRepository catRepo; 
	CategoryCommandToCategory catCToCat;
	CategoryToCategoryCommand catToCatC;
	
	public CategoryServiceImpl(CategoryRepository catRepo, CategoryCommandToCategory catCToCat,
			CategoryToCategoryCommand catToCatC) {
		this.catRepo = catRepo;
		this.catCToCat = catCToCat;
		this.catToCatC = catToCatC;
	}

	@Override
	public Iterable<Category> getCategories() {
		return catRepo.findAll();
	}

	@Override
	public Category findById(Long l) {
		return catRepo.findById(l).get();
	}

	@Override
	@Transactional
	public CategoryCommand saveCategoryCommand(CategoryCommand command) {
		Category detachedCategory = catCToCat.convert(command);
		Category savedCategory = catRepo.save(detachedCategory);
		log.debug("Saved CategoryID: " + savedCategory.getId());
		return catToCatC.convert(savedCategory);
	}

	@Override
	public void deleteById(Long l) {
		catRepo.deleteById(l);
	}

	@Override
	public CategoryCommand findCommandById(Long id) {
		return catToCatC.convert(findById(id));
	}
}

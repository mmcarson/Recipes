package com.marissa.guru.recipes.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.marissa.guru.recipes.command.DirectionCommand;
import com.marissa.guru.recipes.model.Direction;

@Component
public class DirectionToDirectionCommand implements Converter<Direction, DirectionCommand> {

	@Override
	public DirectionCommand convert(Direction source) {
		if (source == null)
			return null;
		final DirectionCommand dirc = new DirectionCommand();
		dirc.setDescription(source.getDescription());
		dirc.setId(source.getId());
		dirc.setStepNumber(source.getStepNumber());
		return dirc;
	}
	
}

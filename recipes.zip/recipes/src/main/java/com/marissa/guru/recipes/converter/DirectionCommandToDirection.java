package com.marissa.guru.recipes.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.marissa.guru.recipes.command.DirectionCommand;
import com.marissa.guru.recipes.model.Direction;

@Component
public class DirectionCommandToDirection implements Converter<DirectionCommand, Direction> {

	@Override
	public Direction convert(DirectionCommand source) {
		if (source == null)
			return null;
		final Direction dir = new Direction();
		dir.setDescription(source.getDescription());
		dir.setId(source.getId());
		dir.setStepNumber(source.getStepNumber());
		return dir;
	}

}

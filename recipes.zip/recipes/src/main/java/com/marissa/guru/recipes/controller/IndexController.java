package com.marissa.guru.recipes.controller;

import java.util.Optional;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.marissa.guru.recipes.command.CategoryCommand;
import com.marissa.guru.recipes.command.RecipeCommand;
import com.marissa.guru.recipes.converter.RecipeToRecipeCommand;
import com.marissa.guru.recipes.model.Category;
import com.marissa.guru.recipes.model.Recipe;
import com.marissa.guru.recipes.model.UnitOfMeasure;
import com.marissa.guru.recipes.repository.CategoryRepository;
import com.marissa.guru.recipes.repository.UnitOfMeasureRepository;
import com.marissa.guru.recipes.service.CategoryService;
import com.marissa.guru.recipes.service.RecipeService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class IndexController {
	
	CategoryService catService;
	RecipeService recService;

	public IndexController(CategoryService catService, RecipeService recService) {
		this.catService = catService;
		this.recService = recService;
	}

	@GetMapping({"","/","index"})
	public String getIndexPage(Model model){
		model.addAttribute("categories", catService.getCategories());
		model.addAttribute("recipes", recService.getRecipes());
		return "index";
	}
	
	@RequestMapping("editor")
	public String getEditor(Model model){
		model.addAttribute("categories", catService.getCategories());
		//model.addAttribute("recipes", recService.getRecipes());
		model.addAttribute("recipe", new RecipeCommand());
		return "editor";
	}
	
	@RequestMapping("editor/{id}")
	public String getEditor(Model model, @PathVariable("id") Long id){
		model.addAttribute("categories", catService.getCategories());
		//model.addAttribute("recipes", recService.getRecipes());
		model.addAttribute("recipe", recService.findCommandById(id));
		return "editor";
	}
	
//	@PostMapping("edited")
	@GetMapping("edited")
	public String saveOrUpdate(@ModelAttribute("recipe") RecipeCommand command){
		RecipeCommand savedCommand = recService.saveRecipe(command);
		/*for (CategoryCommand category: savedCommand.getCategories()){
			catService.saveCategoryCommand(category);
		}*/
		return "redirect:/index" + '#' + savedCommand.getDescription();
	}
	
	@GetMapping("{id}/delete")
	public String deleteById(@PathVariable String id){
		log.debug("Deleting id: " + id);
		recService.deleteById(Long.valueOf(id));
		return "redirect:/";
	}
}
